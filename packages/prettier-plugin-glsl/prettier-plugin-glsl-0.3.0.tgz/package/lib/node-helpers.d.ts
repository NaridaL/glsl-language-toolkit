import { TokenType } from "chevrotain";
export declare function getMatrixDimensions(t: TokenType): [cols: number, rows: number] | undefined;
//# sourceMappingURL=node-helpers.d.ts.map
export declare function recurseJSON(replacer: (this: any, key: string, value: any) => any, x: unknown): any;
export declare const simplifyCst: (x: unknown) => any;
//# sourceMappingURL=gendiagrams.d.ts.map
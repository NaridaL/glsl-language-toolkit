import { Matrix } from "./builtins";
export declare function inverse2(m: Matrix): Matrix;
export declare function determinant2(m: Matrix): number;
export declare function inverse3(m: Matrix): Matrix;
export declare function determinant3(m: Matrix): number;
export declare function inverse4(m: Matrix): Matrix;
export declare function determinant4(m: Matrix): number;
//# sourceMappingURL=matinverse.d.ts.map
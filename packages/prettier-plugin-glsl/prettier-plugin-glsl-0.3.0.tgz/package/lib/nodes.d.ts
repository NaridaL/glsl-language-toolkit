import { IToken } from "chevrotain";
export interface Token extends IToken {
    macroSource?: Token;
    lineNoCont?: number;
}
export declare function getTokenStartLine(token: Token): number;
export interface BaseNode {
    kind: string;
    firstToken?: Token;
    lastToken?: Token;
    tokens?: Token[];
}
export interface BaseExpressionNode extends BaseNode {
}
export interface ArraySpecifier extends BaseNode {
    kind: "arraySpecifier";
    size: Expression | undefined;
}
export interface ArrayAccess extends BaseExpressionNode {
    kind: "arrayAccess";
    on: Expression;
    index: Expression;
}
export interface AssignmentExpression extends BaseExpressionNode {
    kind: "assignmentExpression";
    op: Token;
    lhs: Expression;
    rhs: Expression;
}
export interface BinaryExpression extends BaseExpressionNode {
    kind: "binaryExpression";
    lhs: Expression;
    rhs: Expression;
    op: Token;
}
export interface CommaExpression extends BaseExpressionNode {
    kind: "commaExpression";
    lhs: Expression;
    rhs: Expression;
}
export interface ConditionalExpression extends BaseExpressionNode {
    kind: "conditionalExpression";
    condition: Expression;
    yes: Expression;
    no: Expression;
}
export interface ConstantExpression extends BaseExpressionNode {
    kind: "constantExpression";
    const_: Token;
}
export interface FieldAccess extends BaseExpressionNode {
    kind: "fieldAccess";
    on: Expression;
    field: Token;
}
export interface FunctionCall extends BaseExpressionNode {
    kind: "functionCall";
    callee: TypeSpecifier;
    args: Expression[];
}
export interface MethodCall extends BaseExpressionNode {
    kind: "methodCall";
    on: Expression;
    functionCall: FunctionCall;
}
export interface PostfixExpression extends BaseExpressionNode {
    kind: "postfixExpression";
    on: Expression;
    op: Token;
}
export interface UnaryExpression extends BaseExpressionNode {
    kind: "unaryExpression";
    on: Expression;
    op: Token;
}
export interface VariableExpression extends BaseExpressionNode {
    kind: "variableExpression";
    var: Token;
}
export interface TranslationUnit extends BaseNode {
    kind: "translationUnit";
    declarations: Declaration[];
    comments?: Token[];
}
export interface FunctionDefinition extends BaseNode {
    kind: "functionDefinition";
    name: Token;
    returnType: FullySpecifiedType;
    params: ParameterDeclaration[];
    body: CompoundStatement;
}
export interface FunctionPrototype extends BaseNode {
    kind: "functionPrototype";
    name: Token;
    returnType: FullySpecifiedType;
    params: ParameterDeclaration[];
}
export interface ParameterDeclaration extends BaseNode {
    kind: "parameterDeclaration";
    parameterTypeQualifier: Token | undefined;
    parameterQualifier: Token | undefined;
    pName: Token | undefined;
    arraySpecifier: ArraySpecifier | undefined;
    typeSpecifier: TypeSpecifier;
}
export interface TypeSpecifier extends BaseNode {
    kind: "typeSpecifier";
    precisionQualifier: Token | undefined;
    typeSpecifierNonArray: Token | StructSpecifier;
    arraySpecifier: ArraySpecifier | undefined;
}
export interface CompoundStatement extends BaseNode {
    kind: "compoundStatement";
    statements: Statement[];
    newScope: boolean;
}
export interface ReturnStatement extends BaseNode {
    kind: "returnStatement";
    what: Expression | undefined;
}
export interface ContinueStatement extends BaseNode {
    kind: "continueStatement";
}
export interface BreakStatement extends BaseNode {
    kind: "breakStatement";
}
export interface DiscardStatement extends BaseNode {
    kind: "discardStatement";
}
export interface Declarator extends BaseNode {
    kind: "declarator";
    name: Token;
    arraySpecifier: ArraySpecifier | undefined;
    init: Expression | undefined;
}
export interface DoWhileStatement extends BaseNode {
    kind: "doWhileStatement";
    conditionExpression: Expression;
    statement: Statement;
}
export interface WhileStatement extends BaseNode {
    kind: "whileStatement";
    conditionExpression: Expression | InitDeclaratorListDeclaration;
    statement: Statement;
}
export interface ForStatement extends BaseNode {
    kind: "forStatement";
    initExpression: Statement;
    conditionExpression: Expression | InitDeclaratorListDeclaration | undefined;
    loopExpression: Expression | undefined;
    statement: Statement;
}
export interface ExpressionStatement extends BaseNode {
    kind: "expressionStatement";
    expression: Expression | undefined;
}
export interface UniformBlock extends BaseNode {
    kind: "uniformBlock";
    typeQualifier: TypeQualifier;
    blockName: Token;
    declarations: StructDeclaration[];
    namespace: Token | undefined;
    arraySpecifier: ArraySpecifier | undefined;
}
export type Expression = ArrayAccess | AssignmentExpression | BinaryExpression | CommaExpression | ConditionalExpression | ConstantExpression | FieldAccess | FunctionCall | MethodCall | PostfixExpression | UnaryExpression | VariableExpression;
export declare function isExpression(n: Node): n is Expression;
export interface InitDeclaratorListDeclaration extends BaseNode {
    kind: "initDeclaratorListDeclaration";
    fsType: FullySpecifiedType;
    declarators: Declarator[];
}
export interface PrecisionDeclaration extends BaseNode {
    kind: "precisionDeclaration";
    precisionQualifier: Token;
    typeSpecifierNoPrec: TypeSpecifier;
}
export interface SelectionStatement extends BaseNode {
    kind: "selectionStatement";
    condition: Expression;
    yes: Statement;
    no: Statement | undefined;
}
export interface StorageQualifier extends BaseNode {
    kind: "storageQualifier";
    CENTROID: Token | undefined;
    IN: Token | undefined;
    OUT: Token | undefined;
    VARYING: Token | undefined;
    ATTRIBUTE: Token | undefined;
    CONST: Token | undefined;
    UNIFORM: Token | undefined;
}
export interface SwitchStatement extends BaseNode {
    kind: "switchStatement";
    initExpression: Expression;
    cases: CaseBlock[];
}
export interface CaseLabel extends BaseNode {
    kind: "caseLabel";
    case_: Expression | undefined;
}
export interface CaseBlock extends BaseNode {
    kind: "caseBlock";
    caseLabel: CaseLabel;
    statements: Statement[];
}
export interface FullySpecifiedType extends BaseNode {
    kind: "fullySpecifiedType";
    typeQualifier: TypeQualifier | undefined;
    typeSpecifier: TypeSpecifier;
}
export interface TypeQualifier extends BaseNode {
    kind: "typeQualifier";
    storageQualifier: StorageQualifier | undefined;
    layoutQualifier: LayoutQualifier | undefined;
    interpolationQualifier: Token | undefined;
    invariantQualifier: Token | undefined;
}
export interface StructSpecifier extends BaseNode {
    kind: "structSpecifier";
    name: Token | undefined;
    declarations: StructDeclaration[];
}
export interface LayoutQualifier extends BaseNode {
    kind: "layoutQualifier";
    layoutQualifierIds: {
        IDENTIFIER: Token;
        init: Token | undefined;
    }[];
}
export interface InvariantDeclaration extends BaseNode {
    kind: "invariantDeclaration";
    INVARIANT: Token;
    IDENTIFIER: Token;
}
export interface TypeQualifierDeclaration extends BaseNode {
    kind: "typeQualifierDeclaration";
    typeQualifier: TypeQualifier;
}
export interface StructDeclaration extends BaseNode {
    kind: "structDeclaration";
    fsType: FullySpecifiedType;
    declarators: Declarator[];
}
export interface PpDefine extends BaseNode {
    kind: "ppDefine";
    what: Token;
    params: Token[] | undefined;
    tokens: Token[];
    node: Node | undefined;
}
export interface PpExtension extends BaseNode {
    kind: "ppExtension";
    extension: Token;
    behavior: Token;
}
export interface PpDir extends BaseNode {
    kind: "ppDir";
    dir: Token;
    tokens: Token[];
    node: Node | undefined;
}
export interface PpPragma extends BaseNode {
    kind: "ppPragma";
    dir: Token;
}
export interface PpCall extends BaseNode {
    kind: "ppCall";
    callee: Token;
    args: {
        tokens: Token[];
        node: Node | undefined;
    }[];
}
export interface PpInclude extends BaseNode {
    kind: "ppInclude";
    what: string;
}
export type PpNode = PpDefine | PpDir | PpExtension | PpCall | PpPragma | PpInclude;
export type Declaration = FunctionDefinition | FunctionPrototype | InitDeclaratorListDeclaration | PrecisionDeclaration | InvariantDeclaration | TypeQualifierDeclaration | UniformBlock | PpNode;
export type JumpStatement = ReturnStatement | ContinueStatement | BreakStatement | DiscardStatement;
export type IterationStatement = DoWhileStatement | ForStatement | WhileStatement;
export type Statement = CaseLabel | CompoundStatement | ExpressionStatement | IterationStatement | JumpStatement | SelectionStatement | SwitchStatement | InitDeclaratorListDeclaration | PpNode;
export type Node = ArraySpecifier | CaseBlock | Declaration | Declarator | Expression | FullySpecifiedType | LayoutQualifier | ParameterDeclaration | PpNode | Statement | StorageQualifier | StructDeclaration | StructSpecifier | TranslationUnit | TypeQualifier | TypeSpecifier;
export declare class AbstractVisitor<R> {
    protected visit(n: Node | undefined): R | undefined;
    protected arraySpecifier(n: ArraySpecifier): R | undefined;
    protected binaryExpression(n: BinaryExpression): R | undefined;
    protected methodCall(n: MethodCall): R | undefined;
    protected functionCall(n: FunctionCall): R | undefined;
    protected arrayAccess(n: ArrayAccess): R | undefined;
    protected translationUnit(n: TranslationUnit): R | undefined;
    protected assignmentExpression(n: AssignmentExpression): R | undefined;
    protected fieldAccess(n: FieldAccess): R | undefined;
    protected conditionalExpression(n: ConditionalExpression): R | undefined;
    protected postfixExpression(n: PostfixExpression): R | undefined;
    protected commaExpression(n: CommaExpression): R | undefined;
    protected unaryExpression(n: UnaryExpression): R | undefined;
    protected functionDefinition(n: FunctionDefinition): R | undefined;
    protected functionPrototype(n: FunctionPrototype): R | undefined;
    protected parameterDeclaration(n: ParameterDeclaration): R | undefined;
    protected typeSpecifier(n: TypeSpecifier): R | undefined;
    protected compoundStatement(n: CompoundStatement): R | undefined;
    protected returnStatement(n: ReturnStatement): R | undefined;
    protected continueStatement(_n: ContinueStatement): R | undefined;
    protected breakStatement(_n: BreakStatement): R | undefined;
    protected discardStatement(_n: DiscardStatement): R | undefined;
    protected declarator(n: Declarator): R | undefined;
    protected doWhileStatement(n: DoWhileStatement): R | undefined;
    protected whileStatement(n: WhileStatement): R | undefined;
    protected forStatement(n: ForStatement): R | undefined;
    protected expressionStatement(n: ExpressionStatement): R | undefined;
    protected initDeclaratorListDeclaration(n: InitDeclaratorListDeclaration): R | undefined;
    protected precisionDeclaration(n: PrecisionDeclaration): R | undefined;
    protected selectionStatement(n: SelectionStatement): R | undefined;
    protected storageQualifier(_n: StorageQualifier): R | undefined;
    protected switchStatement(n: SwitchStatement): R | undefined;
    protected caseLabel(n: CaseLabel): R | undefined;
    protected caseBlock(n: CaseBlock): R | undefined;
    protected fullySpecifiedType(n: FullySpecifiedType): R | undefined;
    protected typeQualifier(n: TypeQualifier): R | undefined;
    protected structSpecifier(n: StructSpecifier): R | undefined;
    protected layoutQualifier(_n: LayoutQualifier): R | undefined;
    protected invariantDeclaration(_n: InvariantDeclaration): R | undefined;
    protected structDeclaration(n: StructDeclaration): R | undefined;
    protected variableExpression(_n: VariableExpression): R | undefined;
    protected constantExpression(_n: ConstantExpression): R | undefined;
    protected uniformBlock(n: UniformBlock): R | undefined;
    protected ppDefine(n: PpDefine): R | undefined;
    protected ppDir(_n: PpDir): R | undefined;
    protected ppExtension(_n: PpExtension): R | undefined;
    protected ppCall(_n: PpCall): R | undefined;
    protected ppPragma(_n: PpCall): R | undefined;
}
export declare function isToken(x: IToken | Node): x is IToken;
export declare function isNode(x: Token | Node): x is Node;
export declare function findPositionNode(tree: Node, line: number, char: number): [result: Node | undefined, path: Node[]];
//# sourceMappingURL=nodes.d.ts.map
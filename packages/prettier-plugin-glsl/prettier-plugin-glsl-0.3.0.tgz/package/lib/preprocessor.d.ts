import { Token } from "./nodes";
import { CheckError } from "./util";
type SourceMap = {
    columnDiff: number;
    lineDiff: number;
    newOffset: number;
    originalOffset: number;
    length: number;
};
export declare function applyLineContinuations(input: string): {
    result: string;
    changes: SourceMap[];
};
export declare function fixLocations(tokens: Token[], changes: SourceMap[]): void;
export declare function preproc(input: string): Token[];
type MacroDefinitions = Record<string, {
    kind: "function";
    params: string[];
    tokens: Token[];
    definition: Token;
} | {
    kind: "object";
    tokens: Token[];
    definition: Token;
}>;
export declare function preprocMacros(tokens: Token[], start?: number, definitions?: MacroDefinitions, errors?: CheckError[], blockedReplacements?: {
    macroName: string;
    start: number;
    end: number;
}[], blockedReplacementsOffset?: number): Token[];
export {};
//# sourceMappingURL=preprocessor.d.ts.map
export declare const ERRORS: Record<string, string>;
//# sourceMappingURL=errors.d.ts.map
import { Plugin, SupportInfo } from "prettier";
import { IToken } from "chevrotain";
import { AbstractVisitor, Node, Token } from "./nodes";
interface PrettierComment extends Token {
    leading: boolean;
    trailing: boolean;
    printed: boolean;
    value: string;
}
declare module "./nodes" {
    interface BaseNode {
        comments?: PrettierComment[];
    }
}
export declare const CHILDREN_VISITOR: AbstractVisitor<Node[]> & {
    visit(n: Node): Node[];
};
export declare const languages: SupportInfo["languages"];
export declare const parsers: Plugin<Node | IToken>["parsers"];
export declare const printers: Plugin<Node | IToken>["printers"];
export {};
//# sourceMappingURL=prettier-plugin.d.ts.map
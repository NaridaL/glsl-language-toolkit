export type Many<T> = T | T[];
import { Node, Token } from "./nodes";
export declare const DEV: boolean;
export declare function invariant(x: unknown, message?: string): void;
export declare function underline(str: string, start: number, end: number): string;
/**
 * If array, call .map, otherwise just call f on the one object.
 */
export declare function safeMap<T, R>(x: Many<T>, f: (x: T, i: number, arr: Many<T>) => R): Many<R>;
export interface ExpandedLocation {
    startLine: number;
    endLine: number;
    startColumn: number;
    endColumn: number;
}
export declare function mapExpandedLocation(n: Token | Node): ExpandedLocation;
export interface CheckError {
    where: Token | Node;
    loc: ExpandedLocation;
    code: string;
    message: string;
    error: Error;
}
export declare function substrContext(input: string, token: ExpandedLocation): string;
export declare function allDefined<T>(ts: (T | undefined)[]): ts is T[];
export declare function assertNever(_x?: never): never;
export declare function offsetToLineCol(input: string, offset: number): [line: number, col: number];
export declare function lineColToOffset(input: string, line: number, col: number): number;
export declare function ilog<T>(x: T): T;
//# sourceMappingURL=util.d.ts.map
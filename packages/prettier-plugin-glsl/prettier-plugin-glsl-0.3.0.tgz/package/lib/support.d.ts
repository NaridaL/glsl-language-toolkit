import { Node, Token } from "./nodes";
import type { FunctionCall } from "./nodes";
export declare function resolveNodeDefinition(node: Node): Token | undefined;
export declare function resolvePositionDefinition(tree: Node, line: number, column: number): Token | undefined;
export declare function getHighlights(tree: Node, line: number, column: number): Node[];
export declare function getColors(tree: Node): {
    node: FunctionCall;
    color: [number, number, number, number?];
}[];
//# sourceMappingURL=support.d.ts.map
export type Matrix = number[] & {
    rows: number;
};
export declare function Matrix(cols: number, rows: number): Matrix;
export declare function isMatrix(x: number[] | number): x is Matrix;
export declare function applyBuiltinFunction(name: string, args: any[]): any;
//# sourceMappingURL=builtins.d.ts.map
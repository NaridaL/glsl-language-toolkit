import { TokenType } from "chevrotain";
import { Declarator, FunctionDefinition, FunctionPrototype, InitDeclaratorListDeclaration, Node, ParameterDeclaration, StructSpecifier, TranslationUnit } from "./nodes";
import { CheckError } from "./util";
type BasicType = Readonly<{
    kind: "basic";
    type: TokenType;
}>;
type ArrayType = Readonly<{
    kind: "array";
    of: NormalizedType | undefined;
    size: number;
}>;
type StructType = Readonly<{
    kind: "struct";
    specifier: StructSpecifier;
    fields: {
        [name: string]: {
            type: NormalizedType | undefined;
            declarator: Declarator;
        };
    };
}>;
export type ShaderType = "vertex" | "fragment";
export type NormalizedType = BasicType | ArrayType | StructType;
declare function BasicType(type?: TokenType): NormalizedType | undefined;
declare namespace BasicType {
    const FLOAT: NormalizedType;
    const BOOL: NormalizedType;
    const VOID: NormalizedType;
    const INT: NormalizedType;
    const UINT: NormalizedType;
}
export declare function typeString(t: NormalizedType | undefined): string;
type TypeAndValue = {
    type: NormalizedType;
    value: any;
};
export declare function evaluateConstantExpression(n: Node): TypeAndValue | undefined;
export interface FunctionBinding {
    kind: "function";
    overloads: {
        params: NormalizedType[];
        result: NormalizedType;
        def: FunctionDefinition | FunctionPrototype;
    }[];
    builtIn: boolean;
}
export interface StructBinding {
    kind: "struct";
    type: StructType;
}
export interface VariableBinding {
    kind: "variable";
    declaratorList?: InitDeclaratorListDeclaration;
    declarator?: Declarator;
    parameter?: ParameterDeclaration;
    type: NormalizedType | undefined;
}
export declare function check(u: TranslationUnit, shaderType: ShaderType | undefined): CheckError[];
export {};
//# sourceMappingURL=checker.d.ts.map